# QuoteWork Pro — APK Android

## Compilation en 5 minutes sur buildapps.in

### Option A — Android Studio (si installé)
1. Ouvrir Android Studio
2. File → Open → sélectionner le dossier QuoteWorkPro
3. Build → Build Bundle/APK → Build APK
4. L'APK se trouve dans : app/build/outputs/apk/debug/app-debug.apk

### Option B — En ligne sur Buildozer / AppGyver
1. Aller sur https://www.kodular.io ou https://thunkable.com
2. Importer le projet

### Option C — GitHub Actions (recommandé, gratuit)
1. Créer un compte GitHub (gratuit)
2. Nouveau repository → uploader ce dossier
3. Aller dans Actions → Android Build
4. Télécharger l'APK généré automatiquement

## Installer l'APK sur Android
1. Copier l'APK sur le téléphone (USB ou email)
2. Paramètres → Sécurité → Sources inconnues → Autoriser
3. Ouvrir l'APK → Installer

## Fonctionnalités
- Application Android native WebView
- Toutes les prestations : haie, bosquet, élagage, abattage, tonte
- Export PDF direct dans Documents/Devis/
- Historique des devis (localStorage)
- Carnet d'adresses clients
- Fonctionne hors ligne
