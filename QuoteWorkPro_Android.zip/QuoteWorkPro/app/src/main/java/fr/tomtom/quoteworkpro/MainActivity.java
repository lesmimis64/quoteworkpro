package fr.tomtom.quoteworkpro;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);

        // Configuration WebView
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);        // localStorage
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setSupportZoom(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setMediaPlaybackRequiresUserGesture(false);

        // Interface JavaScript → Android pour le PDF
        webView.addJavascriptInterface(new PdfInterface(), "AndroidPDF");

        // WebViewClient
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        // WebChromeClient pour les alertes JS
        webView.setWebChromeClient(new WebChromeClient());

        // Charger le fichier HTML depuis les assets
        webView.loadUrl("file:///android_asset/index.html");

        // Injecter la fonction de téléchargement PDF une fois la page chargée
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Remplacer exportPDF pour utiliser l'interface Android native
                injectPdfExport();
            }
        });
    }

    private void injectPdfExport() {
        String js = "javascript:(function() {" +
            // Surcharger exportPDF pour appeler l'interface Android
            "var _origExport = window.exportPDF;" +
            "window.exportPDF = function() {" +
            "  try {" +
            "    if (!window.lines || window.lines.length === 0) {" +
            "      alert('Ajoutez au moins une ligne au devis avant d exporter.');" +
            "      return;" +
            "    }" +
            "    var subtotal = lines.reduce(function(s,l){ return s + l.qty*l.pu; }, 0);" +
            "    var remiseType = document.getElementById('remise-type').value;" +
            "    var remiseVal = parseFloat(document.getElementById('remise-val').value||0)||0;" +
            "    var remiseMontant = 0;" +
            "    if (remiseVal>0) remiseMontant = remiseType==='pct' ? subtotal*remiseVal/100 : Math.min(remiseVal,subtotal);" +
            "    var totalTTC = subtotal - remiseMontant;" +
            "    var num = document.getElementById('devis-num').value || 'DEVIS';" +
            "    var cNom = document.getElementById('c-nom').value || '';" +
            // Appeler la génération PDF originale puis intercepter le base64
            "    if (window.AndroidPDF) {" +
            "      window._pdfCallback = function(pdfBase64, filename) {" +
            "        AndroidPDF.savePdf(pdfBase64, filename);" +
            "      };" +
            "    }" +
            "    _origExport();" +
            "  } catch(e) {" +
            "    alert('Erreur export: ' + e.message);" +
            "  }" +
            "};" +
            "})();";
        webView.loadUrl(js);
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    // Interface Android exposée au JavaScript
    public class PdfInterface {
        @JavascriptInterface
        public void savePdf(String base64Data, String filename) {
            try {
                // Décoder le base64
                byte[] pdfBytes;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    pdfBytes = Base64.getDecoder().decode(base64Data);
                } else {
                    pdfBytes = android.util.Base64.decode(base64Data, android.util.Base64.DEFAULT);
                }

                // Sauvegarder dans le dossier Documents
                File dir = new File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Devis");
                if (!dir.exists()) dir.mkdirs();

                String safeFilename = filename.replaceAll("[^a-zA-Z0-9_\\-.]", "_");
                File pdfFile = new File(dir, safeFilename);

                FileOutputStream fos = new FileOutputStream(pdfFile);
                fos.write(pdfBytes);
                fos.close();

                // Ouvrir le PDF avec l'app PDF du téléphone
                runOnUiThread(() -> {
                    Toast.makeText(MainActivity.this,
                        "PDF sauvegardé : " + safeFilename, Toast.LENGTH_LONG).show();
                    openPdf(pdfFile);
                });

            } catch (IOException e) {
                runOnUiThread(() ->
                    Toast.makeText(MainActivity.this,
                        "Erreur sauvegarde PDF : " + e.getMessage(), Toast.LENGTH_LONG).show()
                );
            }
        }

        @JavascriptInterface
        public void showToast(String msg) {
            runOnUiThread(() ->
                Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show()
            );
        }
    }

    private void openPdf(File file) {
        Uri uri = FileProvider.getUriForFile(this,
            "fr.tomtom.quoteworkpro.fileprovider", file);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(uri, "application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Installez une app PDF pour ouvrir le fichier.", Toast.LENGTH_LONG).show();
        }
    }
}
